const express = require('express');
const crypto = require('crypto');
const app = express();

const TOKEN = "yourtoken"; // 记得改成你在微信后台的 Token

app.get('/', (req, res) => {
    res.send('WeChat Server is Running');
});

// 微信服务器验证接口
app.get('/wechat', (req, res) => {
    const { signature, timestamp, nonce, echostr } = req.query;

    const tmpStr = [TOKEN, timestamp, nonce].sort().join('');
    const hash = crypto.createHash('sha1').update(tmpStr).digest('hex');

    if (hash === signature) {
        res.send(echostr);
    } else {
        res.send('error');
    }
});

app.listen(10000, () => {
    console.log("Server running on port 10000");
});
